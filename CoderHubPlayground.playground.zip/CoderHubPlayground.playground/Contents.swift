//1.
func add_five(arr: [String]) -> [String] {
    var arr2 = [String]()
    for i in arr {
        arr2.append((i + "5"))
    }
    return arr2
    }
print(add_five(arr: ["code","c"]))
print(add_five(arr: ["test","t"]))
print(add_five(arr: []))
print(add_five(arr: ["book","pencil","pen"]))

//2.
func middle_char(word: String) -> String
{
    let midIndex = word.count / 2
      return String(word[word.index(word.startIndex, offsetBy: midIndex)])
  }
print(middle_char(word: "like"))
//3.
   
func similarOrdered(word1: String, word2: String) -> String {
    let sortedword1 = Array(Set(word1.sorted()))
    let sortedword2 = Array(Set(word2.sorted()))

    var similarOrdered = ""

    for letter in sortedword1 {
        if sortedword2.contains(letter) {
            similarOrdered += String(letter)
        }
    }

    return similarOrdered.isEmpty ? "No matches found" : similarOrdered
}

print(similarOrdered(word1: "me", word2: "meet"))


    

